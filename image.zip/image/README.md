Background images and character skins for several themes of the game
